module ParseLib.Derived
  (
    module ParseLib.Core,
    -- * Derived combinators
    (<$),
    (<*),
    (*>),
    epsilon,
    symbol,
    token,
    pack,
    choice,
    guard,
    satisfy,
    -- * EBNF parser combinators 
    option,
    many,
    some, many1,
    listOf,
    -- * Chain expression combinators
    chainr,
    chainl,
    -- * Greedy parsers
    greedy,
    greedy1,
    -- * End of input
    eof,
    -- * Applications of elementary parsers
    digit,
    newdigit,
    natural,
    integer,
    identifier,
    parenthesised,
    bracketed,
    braced,
    commaList,
    semiList
  )
  where

import ParseLib.Core
import Control.Applicative
import qualified Data.Char as Char
import Data.Function

-- | Parser for epsilon that does return '()'.
epsilon :: Parser s ()
epsilon = succeed ()

-- | Parses a specific given symbol.
symbol :: Eq s  => s -> Parser s s
symbol x = satisfy (==x)

-- | Parses a specific given sequence of symbols.
token :: Eq s => [s] -> Parser s [s]
token = traverse symbol

-- | Takes three parsers: a delimiter, the parser for the
-- content, and another delimiter. Constructs a sequence of
-- the three, but returns only the result of the enclosed
-- parser.
pack :: Parser s a -> Parser s b -> Parser s c -> Parser s b
pack p r q  =  p *> r <* q

-- | Takes a list of parsers and combines them using
-- choice.
choice :: [Parser s a] -> Parser s a
choice = foldr (<|>) empty

-- | Parses an optional element. Takes the default value
-- as its second argument.
option :: Parser s a -> a -> Parser s a
option p d = p <|> succeed d

-- | Same as 'some'. Provided for compatibility with
-- the lecture notes. 'many' and 'some' are already
-- defined (for any Alternative) in Control.Applicative
many1 :: Parser s a -> Parser s [a]
many1 = some

-- | Takes a parser @p@ and a separator parser @s@. Parses
-- a sequence of @p@s that is separated by @s@s.
listOf :: Parser s a -> Parser s b -> Parser s [a]
listOf p s = (:) <$> p <*> many (s *> p)

-- | Takes a parser @pe@ and an operator parser @po@. Parses
-- a sequence of @pe@s separated by @po@s. The results are
-- combined using the operator associated with @po@ in a
-- right-associative way.
chainr  ::  Parser s a -> Parser s (a -> a -> a) -> Parser s a
chainr pe pop = do
  fs <- many $ do
    e1 <- pe
    op <- pop
    pure $ \e2 -> e1 `op` e2
  e <- pe
  pure $ foldr ($) e fs

-- | Takes a parser @pe@ and an operator parser @po@. Parses
-- a sequence of @pe@s separated by @po@s. The results are
-- combined using the operator associated with @po@ in a
-- left-associative way.
chainl  ::  Parser s a -> Parser s (a -> a -> a) -> Parser s a
chainl pe pop  = do
  e <- pe
  fs <- many $ do
    op <- pop
    e2 <- pe
    pure $ \e1 -> e1 `op` e2
  pure $ foldl (&) e fs

-- | Greedy variant of 'many'.
greedy :: Parser s b -> Parser s [b]
greedy p = (:) <$> p <*> greedy p <<|> succeed []

-- | Greedy variant of 'many1'.
greedy1 :: Parser s b -> Parser s [b]
greedy1 p = (:) <$> p <*> greedy p

-- | Succeeds only on the end of the input.
eof :: Parser s ()
eof = look >>= \ xs -> if null xs then succeed () else failp

-- | Succeeds only if the predicate holds on the result.
guard :: (a -> Bool) -> Parser s a -> Parser s a
guard c p = p >>= \a -> if c a then pure a else failp

-- | Takes a predicate and returns a parser that parses a
-- single symbol satisfying that predicate.
satisfy :: (s -> Bool) -> Parser s s
satisfy p = guard p anySymbol

digit  :: Parser Char Char
digit  =  satisfy Char.isDigit

newdigit :: Parser Char Int
newdigit = read . (:[]) <$> digit

natural :: Parser Char Int
natural = foldl (\a b -> a * 10 + b) 0 <$> many1 newdigit

integer :: Parser Char Int
integer = option (negate <$ symbol '-') id  <*>  natural

identifier :: Parser Char String
identifier = (:) <$> satisfy Char.isAlpha <*> greedy (satisfy Char.isAlphaNum)

parenthesised :: Parser Char a -> Parser Char a
parenthesised p = pack (symbol '(') p (symbol ')')

bracketed :: Parser Char a -> Parser Char a
bracketed p = pack (symbol '[') p (symbol ']')

braced :: Parser Char a -> Parser Char a
braced p = pack (symbol '{') p (symbol '}')

commaList :: Parser Char a -> Parser Char [a]
commaList p = listOf p (symbol ',')

semiList :: Parser Char a -> Parser Char [a]
semiList p = listOf p (symbol ';')


