{-# LANGUAGE LambdaCase #-}
module ParseLib.Core
  (
    -- * The type of parsers
    Parser(),
    -- * Elementary parsers
    anySymbol,
    empty, failp,
    succeed, pure,
    -- * Parser combinators
    (<<|>),
    -- * Running parsers
    parse,
    look
  )
  where

import Data.Char
import Data.Traversable
import Data.Maybe
import Control.Monad
import Control.Applicative

-- | An input string is mapped to a list of successful parses.
-- For each succesful parse, we return the result of type 'r',
-- and the remaining input string. The input must be a list of
-- symbols.
newtype Parser s r  =  Parser { runParser :: [s] -> [(r,[s])] }

instance Functor (Parser s) where
  fmap f p  =  Parser (\xs -> [(f y, ys)
                              | (y, ys) <- runParser p xs])

instance Applicative (Parser s) where
  pure      =  succeed 
  p <*> q   =  Parser (\xs -> [(f x,zs)
                              |(f  ,ys) <- runParser p xs
                              ,(  x,zs) <- runParser q ys])

instance Alternative (Parser s) where
  empty     = failp
  p <|> q   =  Parser (\xs -> runParser p xs <> runParser q xs)

infixr 3 <<|>

-- | Biased choice. If the left hand side parser succeeds,
-- the right hand side is not considered. Use with care!
(<<|>) :: Parser s a -> Parser s a -> Parser s a
p <<|> q  =  Parser (\xs -> let r = runParser p xs in if null r then runParser q xs else r)

instance Monad (Parser s) where
  return    =  pure
  p >>= f   =  Parser (\xs -> [(z  ,zs)
                              |(y  ,ys) <- runParser p xs
                              ,(z  ,zs) <- runParser (f y) ys
                              ])

instance MonadPlus (Parser s) where
  mzero     =  empty
  mplus     =  (<|>)

-- | Parses any single symbol.
anySymbol :: Parser s s
anySymbol = Parser (\case
  (x:xs) -> [(x,xs)]
  [] -> [])

-- | Parser that always succeeds, i.e., for epsilon.
succeed :: a -> Parser s a
succeed r = Parser (\xs -> [(r,xs)])

-- | Same as 'empty'; provided for compatibility with the lecture notes.
failp :: Parser s a
failp = Parser (const [])

-- | Runs a parser on a given string.
parse :: Parser s a -> [s] -> [(a,[s])]
parse = runParser

-- | Returns the rest of the input without consuming anything.
look :: Parser s [s]
look = Parser (\xs -> [(xs, xs)])
